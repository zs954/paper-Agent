---
name: paper-format-lock
description: 论文格式锁定与批量排版。当用户提供"论文范稿/论文模板"要求锁定格式，或要求"按模板/按范稿规范论文格式、统一论文格式、排版论文、改格式"时使用本技能。输入范稿 .docx 与待排版 .docx，输出符合范稿全部格式规范的 .docx、格式档案 JSON 与排版报告。触发词：论文范稿、格式锁定、按模板排版、规范格式、统一格式、论文格式。
agent_created: true
---

# 论文格式锁定（Paper Format Lock）

## Overview

把"论文范稿"投入本技能即可锁定其完整格式（页面设置、docDefaults、全部样式定义、角色映射、自动编号、表格边框），生成可复用的格式档案 JSON；再把"需要更改的论文"投入，即可按锁定格式自动排版，输出符合范稿规范的新 docx 与逐段处理报告。

## 运行环境

- Python：`C:\Users\Administrator\.workbuddy\binaries\python\envs\default\Scripts\python.exe`（已装 python-docx）
- 若该解释器导入 docx 失败：先执行
  `C:\Users\Administrator\.workbuddy\binaries\python\envs\default\Scripts\python.exe -m pip install python-docx`
- 脚本位于本技能 `scripts/` 目录：`paperfmt.py`（CLI 入口）、`paperfmt_core.py`（核心库）

## 工作流

### 第一步：锁定范稿格式（lock）

```bash
<PYTHON> scripts/paperfmt.py lock "<范稿.docx>" -o "<profile.json>"
```

从范稿提取：页面设置（纸张/边距，应用到所有节）、docDefaults、全部样式 XML 与定义、
角色映射（标题/一至三级标题/正文/摘要标题/摘要正文/关键词/参考文献标题/参考文献条目/图表题注/表格文字）、
自动编号定义、表格边框。范稿中靠直接格式排版的段落会合成为命名样式（如"论文-标题"）存入档案。

### 第二步：应用到待排版论文（apply）

```bash
<PYTHON> scripts/paperfmt.py apply "<profile.json>" "<待改论文.docx>" -o "<输出.docx>" --report "<报告.md>"
```

执行内容：整体复制范稿样式与 docDefaults → 应用页面设置 → 导入自动编号 →
逐段识别角色并套用对应样式 → 清除与范稿冲突的直接格式（字体/字号/加粗/对齐/行距/缩进），
让样式定义接管 → 表格套用范稿边框与单元格文字格式 → 保存并生成处理报告。
另支持 `run` 子命令（lock+apply 一步完成）与 `verify` 子命令（反提输出档案逐项核对，111 项全过方为合格）。

### 第三步：核对与交付（verify）

```bash
<PYTHON> scripts/paperfmt.py verify "<profile.json>" "<输出.docx>" --report "<核对报告.md>"
```

必须向用户报告核对结果；存在 ❌ 项时逐项说明期望值与实际值。交付物：输出 docx + 排版报告 + 核对报告，
用 present_files 展示。

## 关键规则

1. **角色识别优先级**：关键词段 > 摘要标题 > 参考文献标题 > 首个"像标题"的段落（标题）>
   样式名含 heading/标题 或 outlineLvl > 文本编号（一、/（一）/1. > 参考文献区 > 摘要区 > 图表题注 > 正文。
2. **直接格式清除策略**：仅清除与范稿样式冲突的直接格式；图片段落保留原对齐/缩进；
   表格单元格保留原有加粗（保护表头强调）；run 级上下标（vertAlign）不清除。
3. **段内混合格式**：范稿中"关键词："加粗而后续文字不加粗的写法，会记录为加粗前缀，
   应用时自动拆分 run 还原，不会把整段锁成加粗。
4. **已知局限（需在交付时告知用户）**：页眉/页脚内容不锁定；旧版 .doc 需先另存为 .docx；
   图片本身不处理；正文自动编号依赖范稿 numbering.xml 可导入。

## 示例

用户说："这是老师给的论文模板，帮我把格式锁上，再把我的论文按这个格式排一下"

1. `lock 老师模板.docx -o profile.json`
2. `apply profile.json 我的论文.docx -o 我的论文_已排版.docx --report 排版报告.md`
3. `verify profile.json 我的论文_已排版.docx --report 核对报告.md`
4. present_files 交付三个文件，并摘要核对结果与段落统计。
